document.addEventListener("DOMContentLoaded", function () {
    const registrationForm = document.getElementById("registrationForm");
    const listPendaftar = document.getElementById("listPendaftar");
    const resume = document.getElementById("resume");
    const pendaftarList = [];

    registrationForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const nama = document.getElementById("nama").value;
        const umur = parseInt(document.getElementById("umur").value);
        const uangSaku = parseInt(document.getElementById("uangSangu").value);

        if (nama.length < 10 || umur < 25 || uangSaku < 100000 || uangSaku > 1000000) {
            alert("Data tidak valid. Pastikan nama minimal 10 karakter, umur minimal 25 tahun, dan uang saku antara 100 ribu hingga 1 juta.");
        } else {
            const pendaftar = { nama, umur, uangSaku };
            pendaftarList.push(pendaftar);
            updateListPendaftar();
            registrationForm.reset();
        }
    });

    function updateListPendaftar() {
        const tbody = listPendaftar.querySelector("tbody");
        tbody.innerHTML = "";
        let totalUmur = 0;
        let totalUangSaku = 0;

        pendaftarList.forEach((pendaftar) => {
            const row = document.createElement("tr");
            row.innerHTML = `
                <td>${pendaftar.nama}</td>
                <td>${pendaftar.umur}</td>
                <td>${pendaftar.uangSaku}</td>
            `;
            tbody.appendChild(row);

            totalUmur += pendaftar.umur;
            totalUangSaku += pendaftar.uangSaku;
        });

        const rataRataUmur = totalUmur / pendaftarList.length;
        const rataRataUangSaku = totalUangSaku / pendaftarList.length;

        resume.innerHTML = `Rata-rata pendaftar memiliki uang saku sebesar ${rataRataUangSaku} dengan rata-rata umur ${rataRataUmur}`;
    }
});
